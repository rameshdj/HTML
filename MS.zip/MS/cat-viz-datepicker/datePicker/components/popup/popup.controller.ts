import { DatePickerServices } from "../../services/datePicker.services";
import * as moment from 'moment';
interface IAppliedDate {
    fromDate: Date,
    toDate: Date,
    hour1: string,
    hour2: string,
    min1: string,
    min2: string,
    selectedDateRange: string
}
export class PopupController {
    static $inject: any = ['DatePickerServices', '$rootScope', 'RequestServices'];
    public dateRangeTypes: any;
    public dateRangeValue: string;
    public startDate: any;
    public endDate: any;
    public selectedDateRange: string;
    public fromDateValue: Date;
    public toDateValue: Date;
    public hours: string[] = [];
    public minutes: string[] = [];
    public min1: string = this.minutes[0];
    public hour1: string = this.hours[0];
    public min2: string = this.minutes[0];
    public hour2: string = this.hours[0];
    public myDate: Date;
    public maxDate: Date;
    public appliedDate: IAppliedDate;
    public isDetailDateFlag: boolean;
    constructor(private datePickerServices: DatePickerServices, private $rootScope: angular.IRootScopeService, 
    private requestServices: RequestServices) {
        for (var i = 0; i < 24; i++) {
            this.hours.push(i < 10 ? '0' + i : i.toString());
        }
        for (var i = 0; i < 60; i++) {
            this.minutes.push(i < 10 ? '0' + i : i.toString());
        }
        this.isDetailDateFlag = !angular.equals(this.datePickerServices.detailDateRange, {});
        this.dateRangeValue = this.isDetailDateFlag ? this.datePickerServices.selectedDetailDateRange : this.datePickerServices.selectedDateRange == "" ? "Last 7 Days" : this.datePickerServices.selectedDateRange;
        this.dateRangeTypes = [
            { 'labelKey': '_12Hours_', 'filterName': 'Last 12 hours', 'fnName': 'lastTwelHours' },
            { 'labelKey': '_Today_', 'filterName': 'Today', 'fnName': 'today' },
            { 'labelKey': '_Yesterday_', 'filterName': 'Yesterday', 'fnName': 'yesterday' },
            { 'labelKey': '_7Days_', 'filterName': 'Last 7 Days', 'fnName': 'lastSevenDays' },
            { 'labelKey': '_15Days_', 'filterName': 'Last 15 Days', 'fnName': 'lastFifyteenDays' },
            { 'labelKey': '_30Days_', 'filterName': 'Last 30 Days', 'fnName': 'lastThirtyDays' },
            // { 'filterName': 'Custom Date Range', 'fnName': 'customDate' }
        ];
        this.myDate = new Date();
        this.maxDate = new Date();
        this.dateRangeChange({});
        this.dateRangeValue != 'Custom Date Range' ? this.defaultCustomDate() : false;
    }
    dateRangeChange(form) {
        switch (this.dateRangeValue) {
            case "Last 12 hours": {
                this.endDate = this.myDate;
                var _12hoursago = angular.copy(this.myDate);
                _12hoursago.setHours(_12hoursago.getHours() - 12);
                this.startDate = _12hoursago;
                this.selectedDateRange = this.datePickerServices.formatMyDate(_12hoursago) + " - " + this.datePickerServices.formatMyDate(this.myDate);
                this.copyDateToCustomDateRange();
                break;
            }
            case "Today": {
                this.setDateRange(0);
                break;
            }
            case "Yesterday": {
                this.setDateRange(1);
                break;
            }
            case "Last 7 Days": {
                this.setDateRange(6);
                break;
            }
            case "Last 15 Days": {
                this.setDateRange(14);
                break;
            }
            case "Last 30 Days": {
                this.setDateRange(29);
                break;
            }
            case "Custom Date Range": {
                if (!this.fromDateValue && !this.toDateValue) {
                    let dateRange = this.isDetailDateFlag ? this.datePickerServices.getDetailDateRange() : this.datePickerServices.getDateRange();
                    this.selectedDateRange = dateRange.startTime + " - " + dateRange.endTime;
                    this.fromDateValue = new Date(dateRange.startTime);
                    this.toDateValue = new Date(dateRange.endTime);
                    this.hour1 = dateRange.startTime.substring(11, 13);
                    this.min1 = dateRange.startTime.substring(14, 16);
                    this.hour2 = dateRange.endTime.substring(11, 13);
                    this.min2 = dateRange.endTime.substring(14, 16);
                }
                break;
            }
        }
    }
    setDateRange(dayCount: number) {
        var today = angular.copy(this.myDate), noOfDaysAgo: Date;
        today.setHours(0);
        today.setMinutes(0);
        today.setSeconds(0);
        noOfDaysAgo = angular.copy(today);
        switch (dayCount) {
            case 1:
                today.setDate(today.getDate() - dayCount);
                noOfDaysAgo.setDate(noOfDaysAgo.getDate() - dayCount);
            case 0:
                today.setHours(23);
                today.setMinutes(59);
                today.setSeconds(59);
                break;
            default:
                noOfDaysAgo.setDate(noOfDaysAgo.getDate() - dayCount);
                break;
        }
        this.startDate = noOfDaysAgo;
        this.endDate = today;
        this.selectedDateRange = this.datePickerServices.formatMyDate(this.startDate) + " - " + this.datePickerServices.formatMyDate(this.endDate);
        this.copyDateToCustomDateRange();
    }
    dateChange(form) {
        this.fromDateValue.setHours(parseInt(this.hour1));
        this.toDateValue.setHours(parseInt(this.hour2));
        this.fromDateValue.setMinutes(parseInt(this.min1));
        this.toDateValue.setMinutes(parseInt(this.min2));
        this.fromDateValue.setSeconds(0);
        this.toDateValue.setSeconds(0);
        this.selectedDateRange = this.fromDateValue && this.toDateValue ? this.datePickerServices.formatMyDate(this.fromDateValue) + ' - ' + this.datePickerServices.formatMyDate(this.toDateValue) : "";
    }
    customDate(form) {
        this.selectedDateRange = "";
        form.$setValidity("maxdaterange", true);
        if (this.fromDateValue && this.toDateValue) {
            this.startDate = this.fromDateValue;
            this.endDate = this.toDateValue;
            this.selectedDateRange = this.datePickerServices.formatMyDate(this.fromDateValue) + ' - ' + this.datePickerServices.formatMyDate(this.toDateValue);
            var timeDiff = Math.abs(this.toDateValue.getTime() - this.fromDateValue.getTime()), diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
            if (diffDays > 90) {
                form.$setValidity("maxdaterange", false);
            }
            if (this.fromDateValue <= this.toDateValue) {
                form.$setValidity("daterange", true);
            } else {
                form.$setValidity("daterange", false);
            }
        }
    }
    close(reset): void {
        if (reset) {
            if (typeof this.appliedDate != 'undefined') {
                this.fromDateValue = this.appliedDate.fromDate;
                this.toDateValue = this.appliedDate.toDate;
                this.hour1 = this.appliedDate.hour1;
                this.hour2 = this.appliedDate.hour2;
                this.min1 = this.appliedDate.min1;
                this.min2 = this.appliedDate.min2;
                this.selectedDateRange = this.appliedDate.selectedDateRange;
                this.dateRangeValue = this.datePickerServices.selectedDateRange == "" ? "Last 7 Days" : this.datePickerServices.selectedDateRange;
            } else {
                this.defaultCustomDate();
            }
        }
        this.$rootScope.$broadcast('custom-date-close', {});
    }
    apply(form): void {
        var setDate = () =>{
            let currentDateRange: any;
            console.log('Now summary date range = ' + !this.isDetailDateFlag);
            if (!this.isDetailDateFlag) {
                /*this.datePickerServices.selectedDateRange = this.dateRangeValue;
                this.datePickerServices.setDateRange(this.startDate, this.endDate);
                currentDateRange = this.datePickerServices.getDateRange();*/
                this.requestServices.selectedDateRange = this.dateRangeValue;
                this.requestServices.setDateRange(this.startDate, this.endDate);
                currentDateRange = this.requestServices.getDateRange();
            } else {
                /*this.datePickerServices.selectedDetailDateRange = this.dateRangeValue;
                this.datePickerServices.setDetailDateRange(this.startDate, this.endDate);
                currentDateRange = this.datePickerServices.getDetailDateRange();*/
                this.requestServices.selectedDetailDateRange = this.dateRangeValue;
                this.requestServices.setDetailDateRange(this.startDate, this.endDate);
                currentDateRange = this.requestServices.getDetailDateRange();
            }
            this.close(false);
            this.$rootScope.$broadcast('BC_dateChanged', { isDetailDateFlag: this.isDetailDateFlag, compileDom: true, dateRange: currentDateRange });
        };
        form.$setValidity("daterange", true);
        if (this.dateRangeValue == 'Custom Date Range')
            this.customDate(form);
        if (this.dateRangeValue !== "Custom Date Range")
            setDate();
        else if (form.$valid) {
            this.appliedDate = { fromDate: this.fromDateValue, toDate: this.toDateValue, hour1: this.hour1, hour2: this.hour2, min1: this.min1, min2: this.min2, selectedDateRange: this.selectedDateRange }
            setDate();
        }
    }
    defaultCustomDate() {
        this.toDateValue = angular.copy(this.myDate);
        this.toDateValue.setHours(23);
        this.toDateValue.setMinutes(59);
        this.toDateValue.setSeconds(0);
        var fromDate: Date = angular.copy(this.myDate);
        fromDate.setHours(0);
        fromDate.setMinutes(0);
        fromDate.setSeconds(0)
        this.fromDateValue = new Date(fromDate.getTime() - 6 * 24 * 60 * 60 * 1000);
        this.hour1 = '00';
        this.hour2 = '23';
        this.min1 = '00';
        this.min2 = '59';
    }
    copyDateToCustomDateRange() {
        this.fromDateValue = this.startDate;
        var hour1 = this.fromDateValue.getHours(), min1 = this.fromDateValue.getMinutes();
        this.hour1 = hour1 < 10 ? '0' + hour1 : hour1.toString();
        this.min1 = min1 < 10 ? '0' + min1 : min1.toString();
        this.toDateValue = this.endDate;
        var hour2 = this.toDateValue.getHours(), min2 = this.toDateValue.getMinutes();
        this.hour2 = hour2 < 10 ? '0' + hour2 : hour2.toString();
        this.min2 = min2 < 10 ? '0' + min2 : min2.toString();
    }
}