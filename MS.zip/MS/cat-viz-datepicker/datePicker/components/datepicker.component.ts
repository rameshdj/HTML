import { PopupController } from "./popup/popup.controller";
import { DatePickerServices } from "../services/datePicker.services";
export class DatePickerComponent implements angular.IComponentOptions {
	public template: string;
	public controllerAs: string;
	public controller: any;
	constructor() {
		this.template = require('./datepicker.html');
		this.controllerAs = 'vm';
		this.controller = DatePickerController;
	}	       
}
export class DatePickerController {
	static $inject: Array<string> = ['$mdPanel', '$scope', 'DatePickerServices', 'RequestServices'];
	public startDate: any;
    public endDate: any;
	public datepickerFlag: boolean = false;
	private datepickerPanelRef: any;

	constructor(private $mdPanel: angular.material.IPanelService, private $scope: angular.IScope, 
	public datePickerServices: DatePickerServices, private requestServices: RequestServices){
		//this.customDateRange(this.datePickerServices.setLast7Days().getDateRange());
		this.initialize();
		this.$scope.$on('BC_dateChanged', (event, data) => {
	        if (!data.isDetailDateFlag) {
	            //let customDate: any = this.datePickerServices.getDateRange();
				let customDate: any = this.requestServices.getDateRange();
	            this.customDateRange(customDate);
	        } else {
	        	//let customDate: any = this.datePickerServices.getDetailDateRange();
				let customDate: any = this.requestServices.getDetailDateRange();
	            this.customDateRange(customDate);
	        }
    	});
		this.$scope.$on('set_detail_daterange', (event, data) => {
			this.datePickerServices.selectedDetailDateRange = this.datePickerServices.selectedDateRange;
        	this.datePickerServices.setDetailDateRange(this.datePickerServices.dateRange.startTime, this.datePickerServices.dateRange.endTime);
		});
		this.$scope.$on('set_detail_date_column', (event, data) => {
			this.datePickerServices.selectedDetailDateRange = data.selectedDetailDateRange;
        	this.datePickerServices.setDetailDateRange(data.date, data.date);
		});
    	this.$scope.$on('restore_datelabel', (event, data) => {
    		let customDate: any;
			if(data == 'date_range') {
				customDate = this.requestServices.getDateRange();
			} else if(data == 'detail_data_range') {
				customDate = this.requestServices.getDetailDateRange();
			}
	        this.customDateRange(customDate);
    	});
	}

	initialize() {
		/*this.datePickerServices.setDateRange(new Date('03/02/2017 00:00:00'), new Date('05/10/2017 23:59:59'));
        this.customDateRange(this.datePickerServices.getDateRange());*/
		this.requestServices.setDateRange(new Date('07/24/2017 00:00:00'), new Date('08/08/2017 23:59:59'));
        this.customDateRange(this.requestServices.getDateRange());
		this.createDatePickerPanel();
	}

	createDatePickerPanel() {
		this.datepickerPanelRef = this.$mdPanel.create({
			attachTo: angular.element(document.body),
			controller: PopupController,
			controllerAs: 'dp',
			disableParentScroll: false,
			template: require('./popup/popup.html'),
			hasBackdrop: true,
			position: this.$mdPanel.newPanelPosition().absolute().center(),
			trapFocus: true,
			zIndex: 150,
			clickOutsideToClose: false,
			escapeToClose: true,
			focusOnOpen: true,
			onDomRemoved: () => {
				this.datepickerFlag = false;
			}
		});
	}

	$postLink() {
		let _local = this;
		this.$scope.$on('custom-date-close', (event, data) => {
			_local.datepickerPanelRef.close();
		});	
		this.$scope.$on('Set_Detail_Date', () => {
            let customDate = this.datePickerServices.getDetailDateRange();
            this.customDateRange(customDate);
        });
	}

	openDatePicker() {
		var _local = this;
		this.datepickerPanelRef.open().then(function(){
			_local.datepickerFlag = true;
		});
	}

	customDateRange(customDate) {
        this.startDate = typeof customDate.startTime == "object" ? this.datePickerServices.formatMyDate(customDate.startTime).substring(0, 10) : customDate.startTime.substring(0, 10);
        this.endDate = typeof customDate.endTime == "object" ? this.datePickerServices.formatMyDate(customDate.endTime).substring(0, 10) : customDate.endTime.substring(0, 10);
    }
}