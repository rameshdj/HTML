

import "./styles/datepicker.scss";


import { DatePickerComponent } from "./components/datepicker.component";
import { DatePickerServices } from "./services/datePicker.services";


export default angular.module('cat.viz.datepicker', [])
    .component('datePickerComponent', new DatePickerComponent())
    .service("DatePickerServices", DatePickerServices)
    .name;
