interface IDate {
    startTime?: Date,
    endTime?: Date
}
interface IIntervals {
    daily: string,
    monthly: string,
    weekly: string,
    setDefault(): string,
    interval: string,
    keys: string[],
    getInterval(str?: string): string,
    setInterval(intval: string): string,
    show: boolean,
    disable: {
        daily: boolean,
        weekly: boolean,
        monthly: boolean
    }
}
export class DatePickerServices implements IDataServices {
    public detailDateRange: any = {};
    public dateRange: IDate = {};
    public intervals: IIntervals;
    public previousDateRange: any;
    public selectedDateRange: string = "";
    public selectedDetailDateRange: string = "";
    public currentChartReqParams: any;
    static $inject: Array<string> = ['$q', 'localStorageService', '$http', 'appconfig', '$mdPanel'];
    constructor(private $q: angular.IQService,
        private localStorageService: angular.local.storage.ILocalStorageService,
        private $http: angular.IHttpService, private appconfig: any, private $mdPanel: angular.material.IPanelService) {
        var _local = this;
        /******************************************/
        this.previousDateRange = { startDate: "", endDate: "", selectedDateRange: "" };
        this.dateRange = {};
        this.intervals = {
            daily: 'Daily',
            monthly: 'Monthly',
            weekly: 'Weekly',
            setDefault: function () {
                this.interval = this.daily;
                return this.daily;
            },
            getInterval: function (intval) {
                let interval = typeof intval == "undefined" ? this.interval : intval;
                switch (interval) {
                    case this.daily:
                        return 'day';
                    case this.weekly:
                        return 'week';
                    case this.monthly:
                        return 'month';
                }
            },
            setInterval: function (intval) {
                this.interval = intval;
                return this.interval;
            },
            interval: 'Daily',
            keys: ['daily', 'weekly', 'monthly'],
            show: false,
            disable: {
                daily: false,
                weekly: true,
                monthly: true
            }
        }
    }
    setDateRange(startTime: Date, endTime: Date) {
        this.dateRange.endTime = angular.copy(endTime);
        this.dateRange.startTime = startTime;
        // 23:59:59 Time change
        if (this.dateRange.endTime.getHours() == 0 && this.dateRange.endTime.getMinutes() == 0 && this.dateRange.endTime.getSeconds() == 0) {
            this.dateRange.endTime.setDate(this.dateRange.endTime.getDate() + 1);
            this.dateRange.endTime.setSeconds(endTime.getSeconds() - 1);
        }
    }
    setDetailDateRange(startTime: Date, endTime: Date) {
        // Disable/Enable intervals
        if (startTime != endTime) {
            var days = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60 * 24)
            if (days <= 5) {
                this.intervals.disable.daily = false;
                this.intervals.disable.weekly = this.intervals.disable.monthly = true;
            } else if (days <= 29 && days >= 6) {
                this.intervals.disable.daily = this.intervals.disable.weekly = false;
                this.intervals.disable.monthly = true;
            } else if (days > 29) {
                this.intervals.disable.daily = this.intervals.disable.weekly = this.intervals.disable.monthly = false;
            }
        } else {
            this.intervals.disable.daily = false;
            this.intervals.disable.weekly = this.intervals.disable.monthly = true;
        }
        // 23:59:59 Time change
        var et = angular.copy(endTime);
        if (et.getHours() == 0 && et.getMinutes() == 0 && et.getSeconds() == 0) {
            et.setDate(et.getDate() + 1);
            et.setSeconds(endTime.getSeconds() - 1);
        }
        this.detailDateRange = {
            startTime: startTime,
            endTime: et
        }
    }
    getDetailDateRange() {
        var dateRange = {
            startTime: "",
            endTime: ""
        }
        dateRange.startTime = this.formatMyDate(this.detailDateRange.startTime)
        dateRange.endTime = this.formatMyDate(this.detailDateRange.endTime)
        return dateRange;
    }
    getDateRange() {
        var dateRange = {
            startTime: "",
            endTime: ""
        }
        dateRange.startTime = this.formatMyDate(this.dateRange.startTime)
        dateRange.endTime = this.formatMyDate(this.dateRange.endTime)
        return dateRange;

    }
    formatMyDate(date: Date): string {
        var dd: any = date.getDate(),
            mm: any = date.getMonth() + 1,
            HH: any = date.getHours(),
            min: any = date.getMinutes(),
            ss: any = date.getSeconds();
        var yyyy = date.getFullYear();
        if (dd < 10) dd = '0' + dd;
        if (mm < 10) mm = '0' + mm;
        if (HH < 10) HH = '0' + HH;
        if (min < 10) min = '0' + min;
        if (ss < 10) ss = '0' + ss;
        return mm + '/' + dd + '/' + yyyy + " " + HH + ":" + min + ":" + ss;
    }
    setLast7Days() {
        var _6daysago: Date, today: Date = new Date();
        today.setHours(0);
        today.setSeconds(0);
        today.setMinutes(0);
        _6daysago = angular.copy(today);
        _6daysago.setDate(today.getDate() - 6);
        this.setDateRange(_6daysago, today);
        return this;
    }
}