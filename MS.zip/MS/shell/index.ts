import { ShellComponent } from "./components/shell.component";


export angular
    .module('cat.viz.shell', [])
    .component('shellComponent', new ShellComponent())
    .value('$routerRootComponent', 'shellComponent')
    .name;