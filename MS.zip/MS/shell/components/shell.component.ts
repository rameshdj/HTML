export class ShellComponent implements angular.IComponentOptions {
    public template: string;
    public controllerAs: string;
    public controller: any;
    public $routeConfig: Array<any>;
    constructor() {
        this.template = require('./shell.html');
        this.controllerAs = "vm";
        this.controller = ShellController;
        this.$routeConfig = [
            { path: '/', name: 'Dashboard', component: 'dashboardComponent' },
            //{ path: '/chartservice', name: 'Chartservice', component: 'chartServiceComponent' },
            { path: '/eventchartservice', name: 'Eventchartservice', component: 'eventChartServiceComponent' },
            { path: '/eventdetail', name: 'Eventdetail', component: 'eventdetailComponent' },
            { path: '/eventgrid', name: 'Eventgrid', component: 'eventgridComponent' },
            { path: '/eventdrill', name: 'Eventdrill', component: 'eventdrillComponent' }
        ];
    }
}
export class ShellController {
    public tileOptions: any;
    public chartOptions: any;
    public configData: any;
    public widgets: any;
    public view: string;
    public eventsParams: any;
    static $inject: Array<string> = ['EventsServices', 'CommonServices', '$window', 'RequestServices'];//'CommonServices', '$cookies'];
    constructor(private eventsServices: EventsServices, public commonServices: CommonServices, 
    private $window: angular.IWindowService, private requestServices: RequestServices) {
        
        //public commonServices: CommonServices, public $cookies: angular.cookies.ICookieStoreService
        //this.commonServices.setuserAccessToken(this.$cookies.get('userAccessToken'));

      /*  this.tileOptions = {
                        "sizeX": 1, 
                        "sizeY" : 1, 
                        "title" : "TotalEventCount",
                        "id" : "TotalEventCount_0",
                        "maxed" : false,
                        "isStreaming" :false,
                        "hasInternalDatePicker" : false,
                        "internalNavDataList" :false,
                        "isGrid" : "Chart"
                    };
        this.chartOptions = {
                        "isSelected" : true,
                        "chartType" : "",
                        "chartHolder" : "",
                        "requestParams" : {},
                        "datatype" : "Events",
                        "selectedChartName" : "TotalEventCount",
                        "isServerSorting" : false,
                        "name" : "TotalEventCount",
                        "startTime": "",
                        "endTime": ""
                    };
        this.configData = {"groupWiseSelectedList":{},"availableGroupWiseSelectedList":{},"selectedList":[],"selectedEventList":[],"widgetName":"Total Event Count","groupSelection":{"filterList":[{"filter":{"filterId":"","filterName":"e2e asset","dealerCode":"TD00","CustomerCode":"2969515985","equipments":[{"name":"Level1","value":[]},{"name":"Level2","value":[]},{"name":"Level3","value":[]},{"name":"Level4","value":[{"isSelected":true,"Name":"E2E00004","make":"CAT"}]}],"catRecId":"QPS-1CD13ECF","catCWSName":"ms12","groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10"},"filterId":239,"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","isSelected":true}]},"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","makeSerialNumberList":"CAT|E2E00004","selectedEvent":""
                    }; */
        this.view = 'summary';
        this.widgets = [
                /*{
                    tileOptions: {
                        "sizeX": 1, 
                        "sizeY" : 1, 
                        "title" : "TotalEventCount",
                        "id" : "TotalEventCount_0",
                        "maxed" : false,
                        "isStreaming" :false,
                        "hasInternalDatePicker" : false,
                        "internalNavDataList" :false,
                        "isGrid" : "Chart"
                    },
                    chartOptions: {
                        "isSelected" : true,
                        "chartType" : "",
                        "chartHolder" : "",
                        "requestParams" : {},
                        "datatype" : "Events",
                        "selectedChartName" : "TotalEventCount",
                        "isServerSorting" : false,
                        "name" : "TotalEventCount",
                        "startTime": "",
                        "endTime": ""
                    },
                    configData: {"groupWiseSelectedList":{},"availableGroupWiseSelectedList":{},"selectedList":[],"selectedEventList":[],"widgetName":"Total Event Count","groupSelection":{"filterList":[{"filter":{"filterId":"","filterName":"e2e asset","dealerCode":"TD00","CustomerCode":"2969515985","equipments":[{"name":"Level1","value":[]},{"name":"Level2","value":[]},{"name":"Level3","value":[]},{"name":"Level4","value":[{"isSelected":true,"Name":"E2E00004","make":"CAT"}]}],"catRecId":"QPS-1CD13ECF","catCWSName":"ms12","groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10"},"filterId":239,"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","isSelected":true}]},"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","makeSerialNumberList":"CAT|E2E00004","selectedEvent":""
                    } 
                },*/
                /*{
                    tileOptions: {
                        "sizeX": 1, 
                        "sizeY" : 1, 
                        "title" : "Top 10 Equipments",
                        "id" : "Top10Equipments_0",
                        "maxed" : false,
                        "isStreaming" :false,
                        "hasInternalDatePicker" : false,
                        "internalNavDataList" :false,
                        "isGrid" : "Chart"
                    },
                    chartOptions: {
                        "isSelected" : true,
                        "chartType" : "",
                        "chartHolder" : "",
                        "requestParams" : {},
                        "datatype" : "Events",
                        "selectedChartName" : "TotalEventCount",
                        "isServerSorting" : false,
                        "name" : "Top10Equipments",
                        "startTime": "",
                        "endTime": ""
                    },
                    configData: {"groupWiseSelectedList":{},"availableGroupWiseSelectedList":{},"selectedList":[],"selectedEventList":[],"widgetName":"Total Event Count","groupSelection":{"filterList":[{"filter":{"filterId":"","filterName":"e2e asset","dealerCode":"TD00","CustomerCode":"2969515985","equipments":[{"name":"Level1","value":[]},{"name":"Level2","value":[]},{"name":"Level3","value":[]},{"name":"Level4","value":[{"isSelected":true,"Name":"E2E00004","make":"CAT"}]}],"catRecId":"QPS-1CD13ECF","catCWSName":"ms12","groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10"},"filterId":239,"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","isSelected":true}]},"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","makeSerialNumberList":"CAT|E2E00004","selectedEvent":""} 
                },*/
                /*{
                    tileOptions: {
                        "sizeX": 1, 
                        "sizeY" : 1, 
                        "title" : "Top 10 Events",
                        "id" : "Top10Events_0",
                        "maxed" : false,
                        "isStreaming" :false,
                        "hasInternalDatePicker" : false,
                        "internalNavDataList" :false,
                        "isGrid" : "Chart"
                    },
                    chartOptions: {
                        "isSelected" : true,
                        "chartType" : "",
                        "chartHolder" : "",
                        "requestParams" : {},
                        "datatype" : "Events",
                        "selectedChartName" : "TotalEventCount",
                        "isServerSorting" : false,
                        "name" : "Top10Events",
                        "startTime": "",
                        "endTime": ""
                    },
                    configData: {"groupWiseSelectedList":{},"availableGroupWiseSelectedList":{},"selectedList":[],"selectedEventList":[],"widgetName":"Total Event Count","groupSelection":{"filterList":[{"filter":{"filterId":"","filterName":"e2e asset","dealerCode":"TD00","CustomerCode":"2969515985","equipments":[{"name":"Level1","value":[]},{"name":"Level2","value":[]},{"name":"Level3","value":[]},{"name":"Level4","value":[{"isSelected":true,"Name":"E2E00004","make":"CAT"}]}],"catRecId":"QPS-1CD13ECF","catCWSName":"ms12","groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10"},"filterId":239,"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","isSelected":true}]},"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","makeSerialNumberList":"CAT|E2E00004","selectedEvent":""} 
                },*/
                {
                    tileOptions: {
                        "sizeX": 1, 
                        "sizeY" : 1, 
                        "title" : "Event Count For Selected Days",
                        "id" : "LastNDaysEventCount_0",
                        "maxed" : false,
                        "isStreaming" :false,
                        "hasInternalDatePicker" : false,
                        "internalNavDataList" :false,
                        "isGrid" : "Chart"
                    },
                    chartOptions: {
                        "isSelected" : true,
                        "chartType" : "",
                        "chartHolder" : "",
                        "requestParams" : {},
                        "datatype" : "Events",
                        "selectedChartName" : "Event Count For Selected Days",
                        "isServerSorting" : false,
                        "name" : "LastNDaysEventCount",
                        "startTime": "",
                        "endTime": ""
                    },
                    configData: {"groupWiseSelectedList":{},"availableGroupWiseSelectedList":{},"selectedList":[],"selectedEventList":[],"widgetName":"Total Event Count","groupSelection":{"filterList":[{"filter":{"filterId":"","filterName":"e2e asset","dealerCode":"TD00","CustomerCode":"2969515985","equipments":[{"name":"Level1","value":[]},{"name":"Level2","value":[]},{"name":"Level3","value":[]},{"name":"Level4","value":[{"isSelected":true,"Name":"E2E00004","make":"CAT"}]}],"catRecId":"QPS-1CD13ECF","catCWSName":"ms12","groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10"},"filterId":239,"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","isSelected":true}]},"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","makeSerialNumberList":"CAT|E2E00004","selectedEvent":""} 
                }
            ];
            /*
        this.tileOptions = {
            "sizeX": 1, 
            "sizeY" : 1, 
            "title" : "TotalEventCount",
            "id" : "TotalEventCount_0",
            "maxed" : false,
            "isStreaming" :false,
            "hasInternalDatePicker" : false,
            "internalNavDataList" :false,
            "isGrid" : "Chart"
        };
        this.chartOptions = {
            "isSelected" : true,
            "chartType" : "",
            "chartHolder" : "",
            "requestParams" : {},
            "datatype" : "Events",
            "selectedChartName" : "TotalEventCount",
            "isServerSorting" : false,
            "name" : "TotalEventCount",
            "startTime": "",
            "endTime": ""
        };
        this.configData = {"groupWiseSelectedList":{},"availableGroupWiseSelectedList":{},"selectedList":[],"selectedEventList":[],"widgetName":"Total Event Count","groupSelection":{"filterList":[{"filter":{"filterId":"","filterName":"e2e asset","dealerCode":"TD00","CustomerCode":"2969515985","equipments":[{"name":"Level1","value":[]},{"name":"Level2","value":[]},{"name":"Level3","value":[]},{"name":"Level4","value":[{"isSelected":true,"Name":"E2E00004","make":"CAT"}]}],"catRecId":"QPS-1CD13ECF","catCWSName":"ms12","groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10"},"filterId":239,"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","isSelected":true}]},"groupId":"73ebd037-449d-4f65-8b23-7b413f51ad10","makeSerialNumberList":"CAT|E2E00004","selectedEvent":""};
        */
    }
}