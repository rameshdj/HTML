# AngularJS Unit Testing

This is an example project with 100% test coverage that aims to demonstrate some of the showcased guidelines and
patterns for unit testing AngularJS applications.

To run the tests:

```bash
$ npm install
$ npm test
```