import {IMaintenanceResponse, IMaintenanceInterval } from "./maintenance.model";
import {ColumnDefinition} from "./maintenancegridcolumndefinition";
import {MaintenanceService} from "../../shared/maintenance.service";
import { MaintenanceColumnSettings } from "../column-settings/maintenancecolumnsettings.model";
import {MaintenanceAssetDetailService} from "../../shared/maintenance.asset.detail.service";
import { ICommonFilterService, ICommonNotificationService } from "../../shared/common.filter.service.model";

export class MaintenanceController {
    static NAME: string = "MaintenanceController";

    public loadingPage: boolean = true;
    public loadingMobilePage: boolean = false;
    public isMobileSize: boolean = false;
    public gridOptions: uiGrid.IGridOptions;
    public gridApi: uiGrid.IGridApi;
    public firstPage: number = 1;
    public lastPage: number = 1;
    public isRecordFound: boolean = true;
    public maintenanceTotalCount: number = 0;
    public totalIntervalCount: number = 0;
    public filteredIntervals: IMaintenanceInterval[] = [];
    private sortColumnOrder: any[];
    public isTabSize: boolean = false;
    public maintenanceMobileCurrentPageNo: number;
    public columnSettings: MaintenanceColumnSettings;
    private sortedFieldName: string = "";
    private sortedType: string = "";
    public customerInfo: any;
    public selectedCols: string[];
    public method: string = "GET";
    public postBody: any;
    public queryUrl: string;
    private reportTitle: string = "Maintenance Summary Report";
    public colData: any = [{
        repName: "currentHourMeter",
        colName: "currentHourMeter"
    }, {
            repName: "currentOdometer",
            colName: "currentOdometer"
        }, {
            repName: "assetStatus",
            colName: "assetStatus"
        }, {
            repName: "lastReportedLocationToDisplay",
            colName: "lastReportedLocationToDisplay"
        }, {
            repName: "lastReportedDate",
            colName: "lastReportedDate"
        }, {
            repName: "completedService",
            colName: "completedService"
        }, {
            repName: "fuelPercentage",
            colName: "fuelPercentage"
        }, {
            repName: "dueInfo.dueBy",
            colName: "dueInfo.dueBy"
        }];
    private reportType: string = "MAINTENANCESUMMARY";
    private defaultQueryLimit: number = 20;
    private paginationState: string = "maintenanceSummaryRowsLimit";
    private newQueryLimit: number;
    private gridSpinner: boolean = true;
    private resource: string[] = ["Report", "Notification"];
    private action: string[] = ["ScheduleReport", "Create"];
    private scheduleReportUser: boolean;
    private createUser: boolean;

    /* @ngInject */
    constructor(
        private $scope: ng.IScope,
        private uiGridConstants,
        private MaintenanceService: MaintenanceService,
        private MaintenanceAssetDetailService: MaintenanceAssetDetailService,
        private screenSize: any,
        private $window: ng.IWindowService,
        private MAINTENANCE_URL: string,
        private $state: ng.ui.IStateService,
        private CommonFilterService: ICommonFilterService,
        private CommonNotificationService: ICommonNotificationService,
        private $sessionStorage: any,
        private ADM_APP_FEATURE_ENABLED: boolean) {
        this.initUserRoles();
        this.maintenanceMobileCurrentPageNo = 1;
        // tslint:disable-next-line:no-unused-variable
        let vm = this;
        this.gridOptions = {};
        this.gridOptions.enableColumnResizing = true;
        this.gridOptions.enableFiltering = false;
        this.gridOptions.enableGrouping = false;
        this.gridOptions.enableGridMenu = false;
        this.gridOptions.showGridFooter = false;
        this.gridOptions.showColumnFooter = false;
        this.gridOptions.enablePinning = false;
        this.gridOptions.infiniteScrollDown = true;
        this.gridOptions.infiniteScrollUp = false;
        this.gridOptions.enableColumnMenus = false;
        this.gridOptions.enableCellEdit = false;
        this.gridOptions.enableColumnMoving = true;
        this.gridOptions.infiniteScrollRowsFromEnd = 5;
        this.gridOptions.enableSorting = true;
        this.gridOptions.useExternalSorting = true;
        this.gridOptions.virtualizationThreshold = 30;
        this.gridOptions.data = "vm.filteredIntervals";

        this.loadingPage = false;
        this.isRecordFound = true;
        this.sortColumnOrder = [];
        this.columnSettings = new MaintenanceColumnSettings();

        this.isMobileSize = this.screenSize.is("xs");
        this.loadingMobilePage = this.isMobileSize;

        this.isTabSize = this.screenSize.is("sm");
        this.screenSize.on("xs", (match) => {
            this.isMobileSize = match;
        });

        this.screenSize.on("sm", (match) => {
            this.isTabSize = match;
        }, this.$scope);

        // below logic calculates number of records to load, in larger screens
        let windowHeight = this.$window.innerHeight,
            previousWindowHeight = this.$sessionStorage["windowHeight"],
            isLargeScreen: boolean = (windowHeight >= 850);

        if (previousWindowHeight && (previousWindowHeight > windowHeight)) {
            //persisiting previous pagination state when the window size reduced
            this.defaultQueryLimit = this.$sessionStorage.pagination[this.paginationState];
        } else {
            this.$sessionStorage["windowHeight"] = windowHeight;
            if (isLargeScreen) {
                //calculating required number of records to fill the grid with available height, when constructor loads
                this.newQueryLimit = Math.ceil((windowHeight - 195) / 30) + 2;
                this.defaultQueryLimit = this.newQueryLimit;
                // Upon resize, if newQueryLimit is greater than queryLimit in session, resetting session with newQueryLimit
                if (this.$sessionStorage.pagination[this.paginationState] && (this.newQueryLimit > this.$sessionStorage.pagination[this.paginationState])) {
                    this.CommonFilterService.setPagination(this.paginationState, this.newQueryLimit);
                }
            }
        }

        this.$sessionStorage.pagination[this.paginationState] = (this.$sessionStorage.pagination[this.paginationState]) ? this.$sessionStorage.pagination[this.paginationState] : this.defaultQueryLimit;

        if (!this.$sessionStorage.maintenanceDateRange) {
            this.CommonFilterService.getMaintenanceFilterStateForDashboard(this.CommonFilterService.filterState, "MAINTENANCE_NEXT_MONTH", true);
        }

        MaintenanceService.getColumnSettings().then((columnSettings: MaintenanceColumnSettings) => {
            this.columnSettings = columnSettings;
        });

        let scrollEventHandler = () => {
            if (this.isMobileSize) {
                if (this.CommonFilterService.isPageEnd() && this.lastPage < this.MaintenanceService.maintenanceTotalPages && !this.loadingMobilePage) {
                    this.lastPage = this.CommonFilterService.getPageNo(this.paginationState, this.lastPage, this.defaultQueryLimit);
                    this.loadingMobilePage = true;
                    this.CommonFilterService.setPagination(this.paginationState, this.lastPage * this.defaultQueryLimit);
                    this.getPage(this.lastPage, this.sortColumnOrder, this.defaultQueryLimit).then(() => {
                        this.loadingMobilePage = false;
                    }, () => {
                        this.loadingMobilePage = false;
                    });
                }
            }
        };

        angular.element(this.$window).bind("scroll", scrollEventHandler);

        // debounce will trigger the below logic once the resizing is done
        let gridResizeHandler = _.debounce(() => {
            let currentWindowHeight = this.$window.innerHeight,
                isLargeScreen: boolean = (currentWindowHeight >= 850);

            if (isLargeScreen) {
                let previousWindowHeight = this.$sessionStorage["windowHeight"],
                    isWindowSizeExpanded: boolean = (currentWindowHeight > previousWindowHeight),
                    isMoreDataRequired: boolean = (this.filteredIntervals.length !== this.maintenanceTotalCount);

                this.$sessionStorage["windowHeight"] = currentWindowHeight;
                if (isWindowSizeExpanded && isMoreDataRequired) {
                    //calculating required number of records to fill the grid with available height, when window resizes
                    this.newQueryLimit = Math.ceil((currentWindowHeight - 195) / 30) + 2;
                    this.defaultQueryLimit = this.newQueryLimit;
                    this.CommonFilterService.resetPagination(this.paginationState, this.defaultQueryLimit);
                    if (this.newQueryLimit <= this.filteredIntervals.length) {
                        //Extracting required number of records from already loaded data
                        this.lastPage = 1;
                        this.filteredIntervals = this.filteredIntervals.splice(0, this.newQueryLimit);
                        this.$scope.$apply();
                    } else {
                        //Fetching required number of records from api
                        $state.reload();
                    }
                }
            }
        }, 200);

        angular.element(this.$window).resize(gridResizeHandler);        

        let clearStateChangeSuccess = this.$scope.$on("$stateChangeSuccess", (event, toState, toParams, fromState, fromParams) => {
            if ((fromState.name !== toState.name) && fromState.name === "maintenance") {
                angular.element(this.$window).unbind("scroll", scrollEventHandler);
            }
        });

        // unbind from scrolling and resize when the controller is destroyed
        this.$scope.$on("$destroy", () => {
            angular.element(this.$window).unbind("scroll", scrollEventHandler);
            angular.element(this.$window).off("resize", gridResizeHandler);
            clearStateChangeSuccess();
        });

        this.CommonFilterService.loadFromQuerystring();
        this.gridOptions.columnDefs = ColumnDefinition.definitions;
        this.gridOptions.onRegisterApi = (gridApi) => {
            this.gridApi = gridApi;
            gridApi.infiniteScroll.on.needLoadMoreData(this.$scope, () => {
                if (this.lastPage < this.MaintenanceService.maintenanceTotalPages) {
                    this.lastPage = this.CommonFilterService.getPageNo(this.paginationState, this.lastPage, this.defaultQueryLimit);
                    return this.getPage(this.lastPage, this.sortColumnOrder, this.defaultQueryLimit).then(() => {
                        this.CommonFilterService.setPagination(this.paginationState, this.lastPage * this.defaultQueryLimit); // Paginaiton Persistence - persisting the increased row count
                        this.gridApi.infiniteScroll.saveScrollPercentage();
                        if (this.filteredIntervals.length === this.totalIntervalCount) {
                            return this.gridApi.infiniteScroll.dataLoaded(false, false);
                        } else if (this.totalIntervalCount) {
                            return this.gridApi.infiniteScroll.dataLoaded(false, true);
                        }
                    });
                }
            });

            gridApi.core.on.sortChanged(null, (grid, sortColumns) => {
                if (!this.loadingPage) {
                    this.loadingPage = true;
                    this.sortColumnOrder = sortColumns;
                    this.sortChanged(grid);
                }
            });

            gridApi.core.on.rowsRendered(this.$scope, () => {
                if (angular.element(".ui-grid-viewport")[0]) {
                    angular.element(".ui-grid-viewport")[0].scrollTop = 0; //  this.gridApi.core.scrollTo(this.gridOptions.data[0], this.gridOptions.columnDefs[0]);
                }
            });
        };

        this.getPage(this.firstPage, this.sortColumnOrder, this.$sessionStorage.pagination[this.paginationState])
            .then(() => {
                this.gridSpinner = this.loadingMobilePage = false;
                if (this.gridApi && this.filteredIntervals.length === this.maintenanceTotalCount) {
                    this.gridApi.infiniteScroll.dataLoaded(false, false);
                }
            }, (error) => {
                this.gridSpinner = this.loadingMobilePage = false;
            });
    }

    initUserRoles() {
        this.CommonFilterService.getUserPermission(this.action[0], this.resource[0]).then((hasPermission) => {
            this.scheduleReportUser = this.ADM_APP_FEATURE_ENABLED ? hasPermission : false;
        });

        this.CommonFilterService.getUserPermission(this.action[1], this.resource[1]).then((hasPermission) => {
            this.createUser = this.ADM_APP_FEATURE_ENABLED ? hasPermission : false;
        });
    }

    public generateReportMaintenanceSummary(): void {
        var selectedColumns = this.columnSettings.selectionColumns;
        this.selectedCols = ["assetID", "assetSerialNumber", "makeCode", "model", "service", "serviceStatus", "dueAt", "dueDate"];
        _.each(selectedColumns, (cols: string,index: number) => {
            var colTemp: any = _.where(this.colData, { colName: cols });
            if (colTemp.length) {
                if (colTemp[0].repName === "lastReportedLocationToDisplay") {
                    colTemp[0].repName = "location";
                }
                if (colTemp[0].repName === "dueInfo.dueBy") {
                    colTemp[0].repName = "dueBy";
                }
                this.selectedCols.push(colTemp[0]["repName"]);
            }
        });        
        this.method = "GET";
        this.postBody = null;
        this.queryUrl = `${this.MAINTENANCE_URL}summary?${this.CommonFilterService.getMaintenanceParams(0, "queryString", this.sortedFieldName, this.sortedType, true)}`;
    }

    public refreshGrid() {
        this.loadingPage = true;
        this.isRecordFound = true;
        this.firstPage = 1;
        this.lastPage = 1;
        this.sortColumnOrder = [];
        this.maintenanceTotalCount = 0;
        this.totalIntervalCount = 0;
        this.filteredIntervals = [];

        this.getPage(this.firstPage, this.sortColumnOrder, this.defaultQueryLimit)
            .then(() => {
                this.loadingPage = this.loadingMobilePage = false;
            }, (error) => {
                this.loadingPage = this.loadingMobilePage = false;
            });
    }

    public getPage(page: number, sortColumns: uiGrid.IGridColumn[], defaultLimit?: number) {
        let sortField: string = "";
        let sortType: string;
        if (sortColumns.length > 0) {
            let nameList = sortColumns[0].field.split(".");
            sortField = (nameList.length === 2) ? nameList[1] : nameList[0];

            if (sortColumns[0].sort.direction === "asc") {
                sortType = "asc";
            } else {
                sortType = "desc";
            }
        }

        this.sortedFieldName = sortField;
        this.sortedType = sortType;

        return this.MaintenanceService.getMaintenanceData(page, sortField, sortType, defaultLimit).then((success: IMaintenanceResponse) => {
            this.maintenanceTotalCount = this.MaintenanceService.maintenanceTotalCount;
            this.filteredIntervals = this.filteredIntervals.concat(success.maintenanceIntervals);
            this.totalIntervalCount = success.totalCount;
            this.gridOptions.virtualizationThreshold = 1 + this.totalIntervalCount;
            this.isRecordFound = (this.totalIntervalCount > 0);
            this.$scope.$broadcast("rowsCount", this.totalIntervalCount);
            this.updateColumnsSettings(this.columnSettings.availableColumns, this.columnSettings.selectionColumns);
        }, (error) => {
            this.isRecordFound = false;
        });
    }

    public showColumnSettingsDialog(): void {
        this.MaintenanceService.showColumnSettingsDialog().then((success: MaintenanceColumnSettings) => {
            this.columnSettings = success;
            this.updateColumnsSettings(this.columnSettings.availableColumns, this.columnSettings.selectionColumns);
        });
    }

    private updateColumnsSettings(availableColumns: Array<string>, selectionColumns: Array<string>): void {
        availableColumns.forEach((availableItem) => {
            this.gridOptions.columnDefs.forEach((item, index) => {
                if (item.field === availableItem) { // find the optional column field 
                    item.visible = false; // initially we make all optional column visible false
                    selectionColumns.forEach((selectedItem) => {
                        if (selectedItem === item.field) { // check the selectedItem
                            item.visible = true;
                        }
                    });
                }
            });
        });
        if (this.gridApi) { this.gridApi.grid.refresh(); }
    }

    public sortChanged(gridApi: uiGrid.IGridInstance) {
        this.lastPage = 1;
        this.filteredIntervals = [];
        this.loadingPage = true;

        this.getPage(this.firstPage, this.sortColumnOrder, this.defaultQueryLimit).then(() => {
            this.loadingPage = false;
            this.CommonFilterService.resetPagination(this.paginationState, this.defaultQueryLimit);
            if (this.gridApi) {
                if (this.filteredIntervals.length === this.maintenanceTotalCount) {
                    return this.gridApi.infiniteScroll.dataLoaded(false, false);
                }
                else if (this.maintenanceTotalCount) {
                    return this.gridApi.infiniteScroll.dataLoaded(false, true);
                }
            }
        }, (error) => {
            this.loadingPage = false;
        });
    }

    public openMaintenanceDateRangeFilterDialog(): void {
        this.MaintenanceService.openMaintenanceDateRangeFilterDialog();
    }

    public showRefineAssetsDialog(): void {
        this.MaintenanceService.showRefineAssetsDialog();
    }

    public getServiceDetailsData(serviceRow, index: any): ng.IPromise<any> {
        return this.MaintenanceAssetDetailService.getServiceDetailsData(serviceRow).then((isComplete) => {
            if (isComplete) {
                this.refreshGrid();
            }
        });
    }

    public openAdvancedFilterDialog() {
        this.CommonFilterService.openAdvancedFilterDialog();
    }

    public getSelectedCriteriaCount(): number {
        return this.CommonFilterService.filterState.selectedCriteriaCount();
    }

    public translateServiceStatus(serviceStatus): string {
        let status = {
            "Upcoming": "MAINTENANCE_SERVICE_STATUS_UPCOMING",
            "Overdue": "MAINTENANCE_SERVICE_STATUS_OVERDUE"
        };
        return this.MaintenanceService.translateString(status[serviceStatus]);
    }

    public translateAssetStatus(assetStatus) {
        let status = {
            "Asset Off": "SERVICE_STATUS_ASSET-OFF",
            "Asset On": "SERVICE_STATUS_ASSET-ON",
            "Awaiting First Report": "SERVICE_STATUS_AWAINTING-FIRST-REPORT",
            "Manual": "SERVICE_STATUS_MANUAL",
            "Not Reporting": "SERVICE_STATUS_NOT-REPORTING",
            "Reporting": "SERVICE_STATUS_REPORTING"
        };

        return this.MaintenanceService.translateString(status[assetStatus]);
    }

    public navigatetoAdminApp() {
        this.CommonNotificationService.navigatetoAdminApp(this.isTabSize, this.isMobileSize);
    }

    public resetPagination() {
        this.CommonFilterService.resetPagination("maintenanceDetailsRowsLimit");
        this.CommonFilterService.resetPagination("maintenanceHistoryRowsLimit");
    }
}