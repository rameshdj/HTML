require("angular-ui-grid/ui-grid.js");
require("angular-media-queries/match-media.js");
import MaintenanceModule from "../../index";
import { AssetFilterState } from "vss.uicore.assetfiltering/source/assetfilterstate.model";
import {MaintenanceController} from "./maintenance.controller";
import {MaintenanceComponent} from "./maintenance.component";
import {MaintenanceService} from "../../shared/maintenance.service";
import {MaintenanceAssetDetailService} from "../../shared/maintenance.asset.detail.service";

describe("Controller : Maintenance", function () {
  let controller: MaintenanceController,
    $scope: any,
    screenSize: any,
    $q: ng.IQService,
    $translate: any,
    CommonFilterService: any,
    $state: ng.ui.IStateService,
    $rootScope: ng.IRootScopeService,
    MaintenanceAssetDetailService: MaintenanceAssetDetailService,
    gridApi: uiGrid.IGridApi,
    $element: ng.IRootElementService,
    bindSpy: any,
    httpBackend: any,
    MaintenanceService: MaintenanceService;

  let fakeMaintenanceData = {
    "summaryData": [
      {
        "assetUID": "7968956d-615a-11e5-a605-0050568836ba",
        "assetIcon": 0,
        "assetID": "TTT_PRO_MRET_1",
        "assetSerialNumber": "TMP01001",
        "makeCode": "CAT",
        "model": "Bench",
        "currentHourmeter": 1767,
        "currentOdometer": null,
        "cumulativeFuel": 2200,
        "lastReportedDate": "2016-11-30T23:43:39",
        "fuelLevel": 40,
        "assetStatus": "Reporting",
        "currentLocation": {
          "streetAddress": "Street",
          "city": "city",
          "state": "Florida",
          "zip": "51789",
          "country": "USA"
        },
        "geoLocation": {
          "latitute": "asdasdasdasd",
          "longitute": "24234234234234"
        },
        "service": "PM 1k",
        "serviceId": 1234,
        "completedService": "PM 1",
        "smuType": "EngineHours",
        "dueInfo": {
          "serviceStatus": "Overdue",
          "dueAt": 1000,
          "dueDate": "2016-11-30T23:43:39",
          "dueBy": 50,
          "dueDays": 9
        }
      },
      {
        "assetUID": "7968556d-615a-11e5-a605-0050568836ba",
        "assetIcon": 2,
        "assetID": "PRO_MRET_1",
        "assetSerialNumber": "TMP01001",
        "makeCode": "CAT",
        "model": "Bench",
        "currentHourMeter": 1767,
        "currentOdometer": 15566,
        "cumulativeFuel": null,
        "lastReportedDate": "2016-11-30T23:43:39",
        "fuelLevel": null,
        "assetStatus": "Reporting",
        "currentLocation": {
          "streetAddress": "",
          "city": "",
          "state": "",
          "zip": "",
          "county": "",
          "country": ""
        },
        "geoLocation": {
          "latitute": "",
          "longitute": ""
        },
        "service": "PM 1k",
        "serviceId": 1234,
        "completedService": "PM 2",
        "smuType": "Odometer",
        "dueInfo": {
          "serviceStatus": "Overdue",
          "dueAt": 1000,
          "dueDate": "2016-11-30T23:43:39",
          "dueBy": 50,
          "dueDays": 9
        }
      }
    ],
    "limit": 20,
    "msg": "success",
    "page": 1,
    "pageLinks": [
      {
        "rel": "prev",
        "href": "/Maintenance/v1?page=1&limit=20",
        "method": "Post"
      },
      {
        "rel": "self",
        "href": "/Maintenance/v1?page=2&limit=20",
        "method": "Post"
      },
      {
        "rel": "next",
        "href": "/Maintenance/v1?page=3&limit=20",
        "method": "Post"
      }
    ],
    "total": 20
  };

  let fakePrefVal: any = { "value": { "defaultColumns": ["string"], "selectionColumns": ["string"], "availableColumns": ["string"] } };
  let MAINTENANCE_URL = "https://api-stg.trimble.com/t/trimble.com/vss-dev-plannedmaintenance/v1/";
  let sortColumns: any = [{
    sort: {
      direction: "asc"
    },
    field: "serviceName"
  }];

  beforeEach(angular.mock.module(MaintenanceModule));

  beforeEach(angular.mock.module(function ($provide: ng.auto.IProvideService) {
    var mockGridapi: any = {
      grid: {
        refresh: jasmine.createSpy("refresh")
      },
      infiniteScroll: {
        on: {
          needLoadMoreData: jasmine.createSpy("needLoadMoreData")
        },
        saveScrollPercentage: jasmine.createSpy("saveScrollPercentage"),
        dataLoaded: jasmine.createSpy("dataLoaded")
      },
      core: {
        on: {
          sortChanged: jasmine.createSpy("sortChanged"),
          columnVisibilityChanged: jasmine.createSpy("columnVisibilityChanged"),
          rowsRendered: jasmine.createSpy("rowsRendered")
        }
      }

    };
    gridApi = mockGridapi;

    $provide.constant("MAINTENANCE_URL", MAINTENANCE_URL);

    $provide.service("screenSize", function () {
      this.is = jasmine.createSpy("is").and.callFake(function (list) {
        if (list === "xs") {
          return true;
        } else {
          return false;
        }
      });

      this.on = jasmine.createSpy("on").and.callFake(function () {
        return true;
      });
    });

    $provide.service("$state", function () {
      this.go = jasmine.createSpy("go");
    });

    $provide.service("AssetIconService", function () {
      this.getIconUrl = jasmine.createSpy("getIconUrl").and.returnValue("http://fakeiconurl");
    });

    $provide.service("CommonFilterService", function () {
      this.filterState = new AssetFilterState();
      this.getPageNo = jasmine.createSpy("getPageNo").and.returnValue(2);
      this.setPagination = jasmine.createSpy("setPagination").and.returnValue("");
      this.resetPagination = jasmine.createSpy("resetPagination").and.returnValue("");
      this.isPageEnd = jasmine.createSpy("isPageEnd").and.returnValue(true);
      this.getQueryStringParametersFromFilter = jasmine.createSpy("getQueryStringParametersFromFilter").and.returnValue(true);
      this.openAdvancedFilterDialog = jasmine.createSpy("openAdvancedFilterDialog").and.callThrough();
      this.loadFromQuerystring = jasmine.createSpy("loadFromQuerystring").and.callThrough();
      this.getMaintenanceFilterStateForDashboard = jasmine.createSpy("getMaintenanceFilterStateForDashboard").and.callThrough();
      this.getUserPermission = jasmine.createSpy("getUserPermission").and.returnValue({ "then": (successCallBck) => { 
        successCallBck(true);
      } });
    });

    $provide.service("CommonNotificationService", function() {
      this.navigatetoAdminApp = jasmine.createSpy("navigatetoAdminApp").and.callThrough();
      this.getPageNo = jasmine.createSpy("getPageNo").and.callThrough();
      this.resetPagination = jasmine.createSpy("resetPagination").and.callThrough();
    });

    $provide.service("MaintenanceService", function () {
      this.maintenanceTotalPages = 3;
      this.getMaintenanceData = jasmine.createSpy("getMaintenanceData").and.callFake(function () {
        let deferred = $q.defer();
        deferred.resolve(fakeMaintenanceData.summaryData);
        return deferred.promise;
      });

      this.showRefineAssetsDialog = jasmine.createSpy("showRefineAssetsDialog").and.callThrough();

      this.showColumnSettingsDialog = jasmine.createSpy("showColumnSettingsDialog").and.callFake(function () {
        let availableCols = ["currentHourMeter", "currentOdometer", "assetStatus", "currentLocation", "lastReportedDate", "completedService", "fuelLevel"];
        let selectionColumns = ["currentHourMeter"];
        let deferred = $q.defer();
        let columnSettings = {
          "availableColumns": availableCols,
          "selectionColumns": selectionColumns
        };
        deferred.resolve(columnSettings);
        return deferred.promise;
      });
      this.getColumnSettings = jasmine.createSpy("getColumnSettings").and.callFake(function () {
        let deferred = $q.defer();
        deferred.resolve(fakePrefVal.value);
        return deferred.promise;
      });
    });

    $provide.service("$element",function(){});
    $provide.value("$sessionStorage", {
      pagination: {
        maintenanceSummaryRowsLimit: 20
      }
    });
    $provide.constant("ADM_APP_FEATURE_ENABLED", true);
  }));

  beforeEach(inject(function (
    _$rootScope_: ng.IRootScopeService,
    _$httpBackend_,
    $componentController,
    _screenSize_: any,
    _$translate_: any,
    _$state_: any,
    _uiGridConstants_: any,
    _MaintenanceService_: any,
    _MaintenanceAssetDetailService_: any,
    _CommonFilterService_: any,
    _$window_,
    _$element_: ng.IRootElementService,
    _$q_: ng.IQService,
    _$sessionStorage_) {
    httpBackend = _$httpBackend_;
    $rootScope = _$rootScope_;
    screenSize = _screenSize_;
    $q = _$q_;
    $translate = _$translate_;
    MaintenanceService = _MaintenanceService_;
    MaintenanceAssetDetailService = _MaintenanceAssetDetailService_;
    $state = _$state_;
    $scope = _$rootScope_.$new();
    CommonFilterService = _CommonFilterService_;
    $element = _$element_;
    bindSpy = spyOn(angular.element.prototype, "bind");
    controller = $componentController(MaintenanceComponent.NAME, {
      $scope: $scope,
      uiGridConstants: _uiGridConstants_,
      MaintenanceService: MaintenanceService,
      MaintenanceAssetDetailService: MaintenanceAssetDetailService,
      screenSize: screenSize,
      $window: _$window_,
      $state: $state,
      CommonFilterService: _CommonFilterService_,
      $sessionStorage: _$sessionStorage_
    });
    controller.lastPage = 1;
    controller.isMobileSize = true;
    controller.loadingPage = false;
    $rootScope.$apply();
  }));

  it("should init controller", () => {
    expect(controller).toBeDefined();
  });

  it("should hide and visible columns based on optional columns selection", () => {
    controller.showColumnSettingsDialog();
  });

  it("should disable date field when global filter is selected", () => {
    controller.openAdvancedFilterDialog();
    expect(CommonFilterService.filterState.dateRangeFilter.isEnabled).toBe(false);
  });

  it("should match the selected Global filters count", () => {
    expect(controller.getSelectedCriteriaCount()).toBe(0);
  });
  it("should sort the columns", () => {
    controller.sortChanged(null);
  });

  it("should show Refine Asset Dialog", () => {
    controller.showRefineAssetsDialog();
  });

  it("should get the Service Details Data", () => {
    controller.getServiceDetailsData({}, 1);
    controller.refreshGrid();
    expect(controller.lastPage).toBe(1);
  });

  it("onRegisterApi and needLoadMoreData of gridApi to be called", () => {
    var maintenanceData: any = {
      "summaryData": [],
      "limit": 20,
      "msg": "success",
      "page": 1,
      "total": 100
    };

    spyOn(controller, "getPage").and.callThrough();
    controller.filteredIntervals = maintenanceData.summaryData;
    controller.gridOptions.onRegisterApi(gridApi);

    let needLoadMoreData = (gridApi.infiniteScroll.on.needLoadMoreData as jasmine.Spy).calls.first().args[1];
    needLoadMoreData();
    $rootScope.$digest();
    expect(controller.loadingPage).toBeFalsy();
  });

  it("sortChanged of OnregisterAPI to be called ", () => {
    var maintenanceData: any = {
      "summaryData": [],
      "limit": 20,
      "msg": "success",
      "page": 1,
      "total": 100
    };

    controller.filteredIntervals = maintenanceData.summaryData;
    controller.gridOptions.onRegisterApi(gridApi);

    let sortChanged = (gridApi.core.on.sortChanged as jasmine.Spy).calls.first().args[1];
    sortChanged(gridApi, sortColumns);
    $rootScope.$digest();
    expect(controller.loadingPage).toBeFalsy();
  });

  it("should bind scroll event to window", function () {
    spyOn(controller, "getPage").and.callThrough();
    controller.filteredIntervals = fakeMaintenanceData.summaryData;   
    $rootScope.$apply();
    var cb = bindSpy.calls.first().args[1];
    cb();
    expect(controller.lastPage).toBe(2);
  });
  it("should emulate screenSize xs", () => {
    let screensizeCallBack = screenSize.on.calls.first().args[1];
    screensizeCallBack(true);
    expect(controller.isMobileSize).toBeTruthy();
  });
});