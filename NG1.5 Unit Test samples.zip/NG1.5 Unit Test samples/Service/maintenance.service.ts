import {IMaintenanceInterval, IMaintenanceResponse} from "../components/table-view/maintenance.model";
import { AssetIconService } from "vss.ui.utilities/source/asseticon.service";
import * as _ from "lodash";
import { MaintenanceColumnsSettingsController } from "../components/column-settings/maintenancecolumnsettings.controller";
import { PreferencesService } from "vss.ui.utilities/source/preferences/preferences.service";
import { PreferenceModel } from "vss.ui.utilities/source/preferences/preferences.model";
import { MaintenanceColumnSettings } from "../components/column-settings/maintenancecolumnsettings.model";
import { ICommonFilterService } from "../shared/common.filter.service.model";
import { GlobalPreferenceService } from "vss.ui.utilities/source/preferences/globalpreference.service";

export class MaintenanceService {
    static NAME: string = "MaintenanceService";
    private summaryEndPoint = "summary";
    private itemsPerPage: number = 20;
    public limit: number = 20;
    public maintenanceTotalPages: number = 0;
    public maintenanceTotalCount: number = 0;
    /* @ngInject */
    constructor(
        private AssetIconService: AssetIconService,
        private $http: ng.IHttpService,
        private $q: ng.IQService,
        private PreferencesService: PreferencesService,
        public CommonFilterService: ICommonFilterService,
        private $uibModal: any,
        private GlobalPreferenceService: GlobalPreferenceService,
        private MAINTENANCE_URL: string,
        private $translate: ng.translate.ITranslateService,
        private $sessionStorage: any
    ) {

    }

    public getLocationBasedOnPreference(asset: any): string {
        let locationPreference = (this.GlobalPreferenceService.getGlobalPreferencesValue("LocationDisplay") as any).APIValue;
        if (locationPreference === "Address") {
            let list = _.values(asset.location);
            list = _.filter(list, Boolean);
            let str = _.filter(list, function (item) {
                if (!_.isEmpty(item.toString())) {
                    return item;
                }
            }).join(", ");
            return (_.isEmpty(str) ? "-" : str);
        } else {
            let list = _.values(asset.geoLocation);
            let str = _.filter(list, function (item) {
                if (!_.isEmpty(item.toString())) {
                    return item;
                }
            }).join("/");
            return (_.isEmpty(str) ? "-" : str);
        }
    }

    public getMaintenanceData(pageNo?: number, sortField?: any, sortType?: any, defaultLimit?: number): ng.IPromise<IMaintenanceResponse> {
        let deferred = this.$q.defer();
        let successFn = (success) => {
            if (success.status !== 200) {
                deferred.reject("maintenanceIntervals fail");
            } else {
                let maintenanceData: IMaintenanceInterval[] = success.data.summaryData;
                this.maintenanceTotalPages = Math.ceil(success.data.total / this.itemsPerPage);
                this.maintenanceTotalCount = success.data.total;

                maintenanceData.map((asset: IMaintenanceInterval) => {
                    if (!_.isUndefined(asset.assetIcon)) {
                        asset.assetIconUrl = this.AssetIconService.getIconUrl(asset.assetIcon);
                    }
                    asset.lastReportedLocationToDisplay = this.getLocationBasedOnPreference(asset);
                });

                let response: IMaintenanceResponse = {
                    maintenanceIntervals: maintenanceData,
                    totalCount: success.data.total as number
                };
                deferred.resolve(response);
            }
        };

        let errorFn = (error) => {
            deferred.reject("maintenanceIntervals fail");
        };

        let currentLimit = defaultLimit ? defaultLimit : this.limit;
        let params = this.CommonFilterService.getMaintenanceParams(pageNo, "", sortField, sortType, false, currentLimit);
        this.$http.get(`${this.MAINTENANCE_URL}${this.summaryEndPoint}`, { params: params, headers: { "X-Introspect": true } })
            .then(successFn, errorFn);

        return deferred.promise;
    }

    public getColumnSettings(): ng.IPromise<MaintenanceColumnSettings> {
        return this.PreferencesService.getPreferencesByKey("svcapp_maintenancesummary")
            .then((columnPreferences) => {
                columnPreferences = columnPreferences || new PreferenceModel();
                columnPreferences.value = columnPreferences.value || new MaintenanceColumnSettings();
                let columnSettings = MaintenanceColumnSettings.fromPreferences(columnPreferences.value);
                return columnSettings;
            });
    }

    public setColumnSettings(paramcolumnSettings: any): ng.IPromise<any> {
        let columnSettings = {
            value: {
                "columnSettings": paramcolumnSettings.selectionColumns
            },
            schemaVersion: "v1"
        };

        let deferred = this.$q.defer();
        this.PreferencesService.setPreferencesByKey("svcapp_maintenancesummary", columnSettings)
            .then(() => {
                deferred.resolve({});
            });
        return deferred.promise;
    }

    public showColumnSettingsDialog(): ng.IPromise<MaintenanceColumnSettings> {
        let deferred = this.$q.defer();
        let options: ng.ui.bootstrap.IModalSettings = {
            template: require("../components/column-settings/maintenancecolumnsettingslist.html"),
            controller: MaintenanceColumnsSettingsController,
            controllerAs: "vm",
            backdrop: "static",
            bindToController: true,
            keyboard: false,
            resolve: {
                currentcolumnsettings: this.getColumnSettings()
            }
        };

        this.$uibModal.open(options).result.then((modifiedColumnSettings) => {
            this.setColumnSettings(modifiedColumnSettings);
            deferred.resolve(modifiedColumnSettings);
        });
        return deferred.promise;
    }

    public openMaintenanceDateRangeFilterDialog() {
        this.CommonFilterService.openMaintenanceDateRangeFilterDialog();
    }

    public showRefineAssetsDialog() {
        this.CommonFilterService.showMaintenanceRefineDialog();
    }

    public showServicePreviewPopUp(): ng.IPromise<any> {
        let deferred = this.$q.defer();
        let modal = this.$uibModal.open({
            template: require("../components/service-details/print.popup.html"),
            controller: () => {

            },
            windowClass: "print-popup",
            controllerAs: "vm",
            size: "sm",
            resolve: {}
        });
        modal.result.then((resultJson) => {
            deferred.resolve(resultJson);
        });
        return deferred.promise;
    }

    public translateString(key) {
        return this.$translate.instant(key);
    }
}
