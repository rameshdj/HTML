import MaintenanceModule from "../index";
import { GlobalPreferenceService } from "vss.ui.utilities/source/preferences/globalpreference.service";
import { AssetFilterState } from "vss.uicore.assetfiltering/source/assetfilterstate.model.ts";
import {MaintenanceService} from "./maintenance.service";

describe("Service: Maintenance Service ", () => {
  beforeEach(angular.mock.module(MaintenanceModule));
  let maintenance: MaintenanceService,
    assetIconService: any,
    $q: ng.IQService,
    $rootScope: ng.IRootScopeService,
    GlobalPreferenceService: any,
    PreferencesService: any,
    $uibModal: any,
    CommonFilterService: any,
    httpBackend: ng.IHttpBackendService;

  let MAINTENANCE_URL = "https://api-stg.trimble.com/t/trimble.com/vss-dev-plannedmaintenance/v1/";

  let fakeMaintenanceData = {
    "summaryData": [
      {
        "assetUID": "b34833e8-1f21-e311-9ee2-00505688274d",
        "assetIcon": 0,
        "assetID": "z28299007RN",
        "assetSerialNumber": "ZZZ00025",
        "makeCode": "CAT",
        "model": "Bench",
        "serviceType": "ServiceLevel",
        "service": "PM2",
        "serviceId": 73,
        "currentHourMeter": 400,
        "location": {
          "streetAddress": "StreetAddress",
          "city": "City",
          "state": "State",
          "zip": null,
          "county": "County",
          "country": null
        },
        "geoLocation": {
          "latitude": 40.83,
          "longitude": -89.5
        },
        "lastReportedDate": "2017-01-14T00:00:00",
        "currentOdometer": 3000,
        "assetStatus": "Reporting",
        "fuelConsumed": null,
        "fuelPercentage": null,
        "completedService": null,
        "dueInfo": {
          "serviceStatus": "Upcoming",
          "dueAt": 500,
          "dueDate": "2017-02-15T00:00:00",
          "dueBy": 300,
          "dueDays": null
        },
        "smuType": "EngineHours"
      },
      {
        "assetUID": "b34833e8-1f21-e311-9ee2-00505688274d",
        "assetIcon": 0,
        "assetID": "z28299007RN",
        "assetSerialNumber": "ZZZ00025",
        "makeCode": "CAT",
        "model": "Bench",
        "serviceType": "ServiceLevel",
        "service": "PM3",
        "serviceId": 74,
        "currentHourMeter": 400,
        "location": {
          "streetAddress": "",
          "city": "",
          "state": "",
          "zip": null,
          "county": "",
          "country": null
        },
        "geoLocation": {
          "latitude": 40.83,
          "longitude": -89.5
        },
        "lastReportedDate": "2017-01-14T00:00:00",
        "currentOdometer": 3000,
        "assetStatus": "Reporting",
        "fuelConsumed": null,
        "fuelPercentage": null,
        "completedService": null,
        "dueInfo": {
          "serviceStatus": "Upcoming",
          "dueAt": 1000,
          "dueDate": "2017-03-30T00:00:00",
          "dueBy": 700,
          "dueDays": null
        },
        "smuType": "EngineHours"
      }],
    "limit": 20,
    "msg": "success",
    "page": 1,
    "pageLinks": [
      {
        "rel": "prev",
        "href": "/Maintenance/v1?page=1&limit=20",
        "method": "Post"
      },
      {
        "rel": "self",
        "href": "/Maintenance/v1?page=2&limit=20",
        "method": "Post"
      },
      {
        "rel": "next",
        "href": "/Maintenance/v1?page=3&limit=20",
        "method": "Post"
      }
    ],
    "total": 20
  };

  let columnSettings = {
    "columnSettings": [
      "currentHourMeter",
      "lastReportedDate",
      "completedService",
      "fuelLevel"
    ]
  };

  let fakePrefVal = { "value": { "defaultColumns": ["string"], "selectionColumns": ["string"], "availableColumns": ["string"] } };
  let locationPref = { "APIValue": "Address" };
  let fakeLanguagePrefs = { "Language": { "APIValue": "en-US" } };
  beforeEach(angular.mock.module(MaintenanceModule));

  beforeEach(angular.mock.module(($provide: ng.auto.IProvideService) => {
    $provide.service("AssetIconService", function () {
      this.getIconUrl = jasmine.createSpy("getIconUrl").and.returnValue("http://fakeiconurl");
    });

    $provide.service("PreferencesService", function () {
      this.getPreferencesByKey = function (fakekey) { return fakePrefVal; };
      this.setPreferencesByKey = function (fakekey, fakePrefVal) { };
    });

    $provide.service("$uibModal", function ($q: ng.IQService) {
        this.open = jasmine.createSpy("open")
            .and.callFake(function () {
                return { result: $q.when({ "columnSettings": "" }) };
            });
    });

    $provide.service("GlobalPreferenceService", function () {
      this.getGlobalPreferencesValue = function () { return locationPref; };
      this.resetGlobalPreferenceValue = function () {
        locationPref = { "APIValue": "GeoLocation" };
      };
      this.getGlobalPreferences = function () { return fakeLanguagePrefs; };
    });

    $provide.service("CommonFilterService", function () {
      this.isPageEnd = jasmine.createSpy("isPageEnd").and.returnValue(true);
      this.getQueryStringParametersFromFilter = jasmine.createSpy("getQueryStringParametersFromFilter").and.returnValue({});
      this.setFilters = jasmine.createSpy("setFilters").and.callThrough();
      this.filterState = new AssetFilterState();
      this.setFilterDateRangeFromSessionStorage = jasmine.createSpy("setFilterDateRangeFromSessionStorage").and.callThrough();
      this.openMaintenanceDateRangeFilterDialog = jasmine.createSpy("openMaintenanceDateRangeFilterDialog").and.callThrough();
      this.getMaintenanceParams = jasmine.createSpy("getMaintenanceParams").and.returnValue({});
    });

    $provide.constant("MAINTENANCE_URL", MAINTENANCE_URL);

    $provide.value("$sessionStorage", {
      SERVICE_MAINTENANCE: { "serviceType": [], "serviceStatus": ["Upcoming"], "assetType": [] },
      maintenanceDateRange: { "selectionType": "custom", "fromDate": "03/22/17", "toDate": "04/13/2017" }
    });
  }));

  beforeEach(inject((
    _$rootScope_: ng.IRootScopeService,
    _$httpBackend_: ng.IHttpBackendService,
    _$q_: ng.IQService,
    _MaintenanceService_: MaintenanceService,
    _GlobalPreferenceService_: GlobalPreferenceService,
    _AssetIconService_: any,
    _PreferencesService_ : any,
    _$uibModal_: any,
    _CommonFilterService_: any
  ) => {
    $uibModal = _$uibModal_;
    $rootScope = _$rootScope_;
    httpBackend = _$httpBackend_;
    $q = _$q_;
    GlobalPreferenceService = _GlobalPreferenceService_;
    assetIconService = _AssetIconService_;
    PreferencesService = _PreferencesService_;
    CommonFilterService = _CommonFilterService_;
    maintenance = _MaintenanceService_;
  }));

  it("should retrieve maintenance data when getMaintenanceData method passes", function () {
    httpBackend.when("GET", new RegExp(MAINTENANCE_URL + ".*")).respond(fakeMaintenanceData);
    maintenance.getMaintenanceData(1).then(function (success) {
      expect(success.maintenanceIntervals.length).toEqual(fakeMaintenanceData["summaryData"].length);
    });
    httpBackend.flush();
  });

  it("should return concat string when an objct is passed", () => {
    expect(maintenance.getLocationBasedOnPreference(fakeMaintenanceData["summaryData"][0])).toBe("StreetAddress, City, State, County");
  });

  it("should return concat string - when an empty object is passed", () => {
    expect(maintenance.getLocationBasedOnPreference(fakeMaintenanceData["summaryData"][1])).toBe("-");
  });

  it("should return concat string when any property is empty", () => {
    expect(maintenance.getLocationBasedOnPreference({ "location": { "streetAddress": "", "city": "", "state": "Florida", "zip": "", "country": "" } })).toBe("Florida");
  });

  it("should return concat string when any property is empty", () => {
    GlobalPreferenceService.resetGlobalPreferenceValue();
    expect(maintenance.getLocationBasedOnPreference({ "geoLocation": { "latitude": "lat", "longitute": "987654321" } })).toBe("lat/987654321");
  });

  it("should return concat string when any property is empty", () => {
    GlobalPreferenceService.resetGlobalPreferenceValue();
    expect(maintenance.getLocationBasedOnPreference({ "geoLocation": { "latitude": "", "longitute": "" } })).toBe("-");
  });

  it("should retrieve maintenance column settings", function () {
    spyOn(PreferencesService, "getPreferencesByKey").and.returnValue($q.when(columnSettings));
    maintenance.getColumnSettings();
    $rootScope.$apply();
    expect(PreferencesService.getPreferencesByKey).toHaveBeenCalled();
  });

  it("should set maintenance column settings", function () {
    spyOn(PreferencesService, "setPreferencesByKey").and.returnValue($q.when(columnSettings));
    maintenance.setColumnSettings(columnSettings);
    $rootScope.$apply();
    expect(PreferencesService.setPreferencesByKey).toHaveBeenCalled();
  });

  it("should open column settings dialog", () => {
    spyOn(PreferencesService, "getPreferencesByKey").and.returnValue($q.when(columnSettings));
    spyOn(PreferencesService, "setPreferencesByKey").and.returnValue($q.when(columnSettings));
    maintenance.showColumnSettingsDialog();
    $rootScope.$digest();
    expect($uibModal.open).toHaveBeenCalled();
  });

  it("should open maintenance date range dialog", () => {
    maintenance.openMaintenanceDateRangeFilterDialog();
    expect(CommonFilterService.openMaintenanceDateRangeFilterDialog).toHaveBeenCalled();
  });

  it("should show Service Preview PopUp" , () => {
    maintenance.showServicePreviewPopUp();
  });

  it("should translate string", () => {
    maintenance.translateString("maintenance");
  });
});