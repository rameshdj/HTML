import MaintenanceModule from "../../index.ts";
import {MaintenanceColumnsSettingsController} from "./maintenancecolumnsettings.controller";

describe("Controller :: MaintenanceColumnsSettingsController ", () => {
  let controller: MaintenanceColumnsSettingsController, $uibModalInstance: any;

  beforeEach(angular.mock.module(MaintenanceModule));

  beforeEach(angular.mock.module(function ($provide: ng.auto.IProvideService) {
    $provide.service("$uibModalInstance", function () {
      this.dismiss = jasmine.createSpy("dismiss").and.callThrough();
    });

    $provide.service("currentcolumnsettings", () => { });
  }));

  beforeEach(inject(function (
    _$uibModalInstance_: ng.ui.bootstrap.IModalServiceInstance,
    _$rootScope_: ng.IRootScopeService,
    _currentcolumnsettings_: any,
    _$controller_: ng.IControllerService
  ) {
    $uibModalInstance = _$uibModalInstance_;
    controller = _$controller_(
      MaintenanceColumnsSettingsController,
      {
        $uibModalInstance: $uibModalInstance,
        _currentcolumnsettings_
      });
  }));

  it("should init controller", () => {
    expect(controller).toBeDefined();
  });

  it("should close maintenance column settings dialog on call clase()", () => {
    controller.close();
  });
});
