import { MaintenanceColumnSettings } from "./maintenancecolumnsettings.model";

export class MaintenanceColumnsSettingsController {
    static NAME: string = "MaintenanceColumnsSettingsController";

    public columnSettings: MaintenanceColumnSettings;

    /*@ngInject*/
    constructor(
        public $uibModalInstance: ng.ui.bootstrap.IModalServiceInstance,
        public currentcolumnsettings
    ) {
        this.columnSettings = currentcolumnsettings;
    }

    public close(): void {
        this.$uibModalInstance.dismiss("cancel");
    }

}