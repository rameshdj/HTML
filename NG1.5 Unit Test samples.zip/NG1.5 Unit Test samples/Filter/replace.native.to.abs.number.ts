export class ReplaceNegativeToAbsNumber {
  static NAME: string = "ReplaceNegativeToAbsNumber";

  /* @ngInject */
  static factory() {
    return function (item) {
      if (item < 0) {
        return Math.abs(item);
      } else {
        return item;
      }
    };
  }
}