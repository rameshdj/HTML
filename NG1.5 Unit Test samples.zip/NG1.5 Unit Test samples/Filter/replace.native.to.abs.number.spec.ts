import {ReplaceNegativeToAbsNumber} from "./replace.native.to.abs.number";
describe("Class : ReplaceNegativeToAbsNumber", () => {
  it("should replace negative to absolute number", () => {
    let factory = ReplaceNegativeToAbsNumber.factory();
    let absNumber = factory(-10);
    let absNumber2 = factory(10);
    expect(absNumber).toBe(10);
    expect(absNumber2).toBe(10);
  });
});